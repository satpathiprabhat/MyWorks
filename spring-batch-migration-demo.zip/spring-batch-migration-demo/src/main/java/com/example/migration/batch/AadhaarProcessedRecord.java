
package com.example.migration.batch;
public class AadhaarProcessedRecord {
  private Long id;
  private byte[] newEncryptedAadhaar;
  public Long getId(){return id;}
  public void setId(Long id){this.id=id;}
  public byte[] getNewEncryptedAadhaar(){return newEncryptedAadhaar;}
  public void setNewEncryptedAadhaar(byte[] newEncryptedAadhaar){this.newEncryptedAadhaar=newEncryptedAadhaar;}
}
