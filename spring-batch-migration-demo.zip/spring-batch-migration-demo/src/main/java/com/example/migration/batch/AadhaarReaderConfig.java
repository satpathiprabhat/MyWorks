
package com.example.migration.batch;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.support.OraclePagingQueryProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Value;

import javax.sql.DataSource;
import java.util.Collections;

@Configuration
public class AadhaarReaderConfig {

  @Bean
  @StepScope
  public JdbcPagingItemReader<AadhaarRecord> reader(
      DataSource ds,
      @Value("#{stepExecutionContext[minId]}") Long minId,
      @Value("#{stepExecutionContext[maxId]}") Long maxId) {

    JdbcPagingItemReader<AadhaarRecord> r=new JdbcPagingItemReader<>();
    r.setDataSource(ds);
    r.setPageSize(500);

    OraclePagingQueryProvider qp=new OraclePagingQueryProvider();
    qp.setSelectClause("IDENTIFICATION_NUMBER");
    qp.setFromClause("FROM DVS_ID_INFO");
    qp.setWhereClause("WHERE MIG_STATUS=“P” AND ROWID BETWEEN " + minId + " AND " + maxId);
    qp.setSortKeys(Collections.singletonMap("ID", org.springframework.batch.item.database.Order.ASCENDING));

    r.setQueryProvider(qp);
    r.setRowMapper((rs,i)->{
      AadhaarRecord a=new AadhaarRecord();
      a.setId(rs.getLong("ID"));
      a.setEncryptedAadhaar(rs.getBytes("ENCRYPTED_AADHAAR"));
      return a;
    });
    return r;
  }
}
