
package com.example.migration.batch;
public class AadhaarRecord {
  private Long id;
  private byte[] encryptedAadhaar;
  public Long getId(){return id;}
  public void setId(Long id){this.id=id;}
  public byte[] getEncryptedAadhaar(){return encryptedAadhaar;}
  public void setEncryptedAadhaar(byte[] encryptedAadhaar){this.encryptedAadhaar=encryptedAadhaar;}
}
